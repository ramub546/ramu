<?php
// Include PHPMailer classes
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {
    // SMTP Configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // For Gmail SMTP
    $mail->SMTPAuth = true;
    $mail->Username = 'ramub9634@gmail.com'; // Replace with your Gmail address
    $mail->Password = 'psux sozu hbbj frlo';   // Replace with your Gmail App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use TLS encryption
    $mail->Port = 587; // TLS port

    // Email Details
    $mail->setFrom('ramub9634@gmail.com', 'Ramu'); // Sender's email
    $mail->addAddress('ganeshbhuvj@gmail.com');      // Recipient's email

    $mail->Subject = 'Test Email from PHPMailer';
    $mail->Body = 'Hello! This is a test email sent using PHPMailer.';

    // Send Email
    $mail->send();
    echo 'Email sent successfully!';
} catch (Exception $e) {
    echo 'Email could not be sent. Error: ', $mail->ErrorInfo;
}
?>
