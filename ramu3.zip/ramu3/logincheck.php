<?php
session_start();

// Include PHPMailer files manually
require_once __DIR__ . '/PHPMailer/src/Exception.php';
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_POST['submit'])) {
    include('conndb.php'); // Ensure this file path is correct
    $Email = mysqli_real_escape_string($conn, $_POST['Email']);
    $Password = mysqli_real_escape_string($conn, $_POST['Password']);
    $_SESSION['Email'] = $Email;

    $query = "SELECT * FROM registration WHERE Email='$Email' AND Password='$Password'";
    $res = mysqli_query($conn, $query);

    if (mysqli_num_rows($res) > 0) {
        $otp = rand(11111, 99999); // Generate OTP
        $_SESSION['otp'] = $otp;   // Save OTP in session

        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'ramub9634@gmail.com'; // Replace with your Gmail address
            $mail->Password = 'psux sozu hbbj frlo';       // Replace with your Gmail app password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('ramub9634@gmail.com', 'RAMU');
            $mail->addAddress($Email); // Send OTP to the user's email

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'OTP';
            $mail->Body    = "This is your OTP: $otp";

            $mail->send();
            header('location:sendotp.html'); // Redirect to OTP verification page
        } catch (Exception $e) {
            echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Wrong credentials";
    }
}
?>
